HOST = "nodelicious.no.de"

var app = require ('./app')
// run it!
console.log("running on http://127.0.0.1/")
app.listen(80)
