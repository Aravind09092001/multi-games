HOST = "localhost:3000"

var app = require ('./app')
// run it!
console.log("running on http://127.0.0.1:3000")

app.listen(3000)
