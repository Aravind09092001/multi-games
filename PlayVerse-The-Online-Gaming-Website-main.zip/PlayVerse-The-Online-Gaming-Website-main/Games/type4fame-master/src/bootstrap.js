require('coffee-script');
var server = require('./server');
module.exports = server;
