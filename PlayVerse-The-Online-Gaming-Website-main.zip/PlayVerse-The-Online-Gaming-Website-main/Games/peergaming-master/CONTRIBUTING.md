Contributions
=============

Currently the Project is still in early development and part of my graduation.

After the stable release is published I can allow further involvement.


## How To

Based on the [Idiomatic Style Guide](https://github.com/rwldrn/idiomatic.js).

For the basic setup, use ```npm install``` which will fetch the required packages.

Just got into the build directory and call _node build_ to merge the sources.
