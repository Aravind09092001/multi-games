/**
 *  Info
 *  ====
 *
 *  A simple interface to provide access for internal data.
 */


extend( INFO, {

  route: null

});

// TODO: 0.6.0 -> data & info
