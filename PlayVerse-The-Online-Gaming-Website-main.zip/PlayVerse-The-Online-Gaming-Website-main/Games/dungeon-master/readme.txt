This app (dungeon) is built using node.js. To run dungeon, use the command
    node server\server.js port-number
Node.js can be downloaded from http://nodejs.org
Dungeon also depends on socket.io. This can be installed with the command
     npm install socket.io