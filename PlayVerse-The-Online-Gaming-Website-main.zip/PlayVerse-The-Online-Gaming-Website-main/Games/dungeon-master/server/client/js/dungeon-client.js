dungeon.Client = function() {
  dungeon.Game.apply(this);
  this.initialize();
}

dungeon.Client.prototype = extend(dungeon.Game.prototype, {
  initialize: function() {
    var self = this;
    window.addEventListener('hashchange', this.processHash.bind(this));
    this.processHash();

    // Repository of powers.
    this.powers = new dungeon.Powers(this);

    this.combatTracker = new dungeon.CombatTracker(this);
    this.characterDetailsPage = new dungeon.CharacterDetailsPage(this);
    this.combatOverviewPage = new dungeon.CombatOverviewPage(this); 
    dungeon.initializeDialogs(this);

    this.canvas = $('game-canvas');
    this.socket = io.connect('http://' + location.host);

    this.socket.on('e', this.receiveEvent.bind(this));
    this.canvas.addEventListener('touchstart', this.onTouchStart.bind(this));
    this.canvas.addEventListener('mousedown', this.onMouseDown.bind(this));
    this.canvas.addEventListener('mousemove', this.onMouseMove.bind(this));
    this.canvas.addEventListener('mousewheel', this.onMouseWheel.bind(this));
    document.body.addEventListener('keyup', this.onKeyUp.bind(this));

    $('attack-button').addEventListener('click', this.attackSelectedTargets.bind(this));
    $('cancel-button').addEventListener('click', this.cancelSelectedTarget.bind(this));

    // Switching between views.
    $('character-selector').addEventListener(
        'click', this.onSelectView.bind(this, 'page', 'character'));
    $('map-selector').addEventListener(
        'click', this.onSelectView.bind(this,'page', 'map'));
    $('combat-overview-selector').addEventListener(
        'click', this.onSelectView.bind(this,'page', 'combat-overview'));
    $('character-import-selector').addEventListener(
        'click', this.onSelectView.bind(this, 'sidebar-page', 'character-import'));
    $('combat-tracker-selector').addEventListener(
        'click', this.onSelectView.bind(this, 'sidebar-page', 'combat-tracker'));

    $('undo-button').addEventListener('click', this.sendEvent.bind(this, {'type': 'undo'}));
    $('save-button').addEventListener('click', this.saveMap.bind(this));

    // Status of combat.
    this.combatState = 'stopped';
    $('combat-start-button').addEventListener('click',
        this.setCombatState.bind(this, 'start'));
    $('combat-pause-button').addEventListener('click',
        this.setCombatState.bind(this, 'pause'));
    $('combat-stop-button').addEventListener('click', 
        this.setCombatState.bind(this, 'stop'));
    this.addEventListener('combat-state-changed', 
        this.onCombatStateChanged.bind(this));
    this.addEventListener('initiative-order-changed',
        this.onInitiativeOrderChanged.bind(this));
    this.addEventListener('character-removed', 
        this.onRemoveCharacter.bind(this));

    // Drag-n-drop of character files.
    var dropZone = $('sidebar');
    dropZone.addEventListener('dragover', this.onFileDragOver.bind(this));
    dropZone.addEventListener('drop', this.onFileDrop.bind(this));
    // Character file chooser
    $('files').addEventListener('change', this.onFileSelect.bind(this));

    // Drag-n-drop of a character from the sidebar onto the map.
    this.canvas.addEventListener('dragover', this.onCharacterDragOver.bind(this));
    this.canvas.addEventListener('drop', this.onCharacterDrop.bind(this));

    window.addEventListener('resize', this.resize.bind(this));
    this.addEventListener('tile-added', this.rebuildTiles.bind(this));
    this.addEventListener('character-loaded', this.updateCharacterRegistry.bind(this));
    this.addEventListener('log', this.logMessage.bind(this));
    this.addEventListener('banner-message', this.displayBannerMessage.bind(this));
    this.addEventListener('character-updated', function(c) {
      var name = self.characterPlacement[c].name;
      var displayed = self.combatTracker.displayedCharacterName();
      if (name == displayed)
        self.dispatchEvent('character-selected', self.characterPlacement[c]);
    });

    this.combatTracker.addEventListener('power-selected', 
                                        this.selectPower.bind(this));

    this.addEventListener('character-selected', function() {
      self.ui.targets = [];
      self.update();
    });
    this.addEventListener('combat-add-target', this.addCombatTarget.bind(this));
    this.addEventListener('dm-attack-result', this.onDmAttackResultMsg.bind(this));
    this.combatTracker.addEventListener('use-power', this.onUsePower.bind(this));
    this.viewport = {
      x: 30,
      y: 30,
      tileSize: 32,
      tileSizeFloat: 32,
    };

    dungeon.Game.prototype.initialize.call(this);
    this.resize();
  },

  processHash: function() {
    var attributes = window.location.hash.substr(1).split('&');
    this.attributes = {};
    for (var i = 0; i < attributes.length; i++) {
      var pos = attributes[i].indexOf('=');
      if (pos == -1) {
        this.attributes[attributes[i]] = true;
      } else {
        this.attributes[attributes[i].substr(0, pos)] =
            attributes[i].substr(pos + 1);
      }
    }
    var role = 'player';
    var ui = 'desktop';
    if (this.attributes.ui)
      ui = this.attributes.ui;
    if (this.attributes.dm)
      role = 'dm';
    document.body.parentNode.setAttribute('role', role);
    document.body.parentNode.setAttribute('ui', ui);
  },

  addCombatTarget: function(index) {
    if (!this.ui.targets)
      this.ui.targets = [];
    this.ui.targets.push(index);
    this.update();
  },

  // TODO: rename since we're really using a power on targets, which may be allies.
  attackTargets: function() {
    var power = this.ui.activePower;
    if (power && this.ui.targets && this.ui.selected !== undefined && this.ui.targets.length) {
      // Power respository handles resolution of power.
      this.dispatchEvent('power-used');
      this.ui.targets = [];
      this.ui.selected = undefined;
      this.ui.path = null;
      this.update();
    }
  },

  getTargets: function() {
    return this.ui.targets;
  },

  getCharacter: function(index) {
    return this.characterPlacement[index];
  },

  getCharacterIndex: function(name) {
    for (var i = 0; i < this.characterPlacement.length; i++) {
      var candidate = this.characterPlacement[i].name;
      if (candidate == name)
        return i;
    }
  },

  getCharacterByName: function(name) {
    var index = this.getCharacterIndex(name);
    return (index != undefined) ? this.getCharacter(index) : undefined;
  },

  /**
   * Select a character and power.
   * @param {string} characterName Name of the character.
   * @param {stirng} powerName Name of the power.
   * @return {boolean} True if successful.
   */
  selectPower: function(characterName, powerName) {
    if (!powerName) {
      this.ui.activePower = null;
      return;
    }
    var success = false;
    if (this.selectCharacterByName(characterName)) {
      success = true;
      var power = this.ui.activePower = this.powers.get(powerName);
      this.dispatchEvent('power-selected', characterName, powerName);
      this.ui.targets = [];
      if(power.autoSelect()) {
        var source = this.characterPlacement[this.ui.selected];
        for (var i = 0; i < this.characterPlacement.length; i++) {
          if (power.selectionMatch(source, this.characterPlacement[i]))
            this.ui.targets.push(i);
        }
        this.update();
      }
    }
    return success;
  },

  /**
   * Selects a character by name.  Multiple monsters in the same group have
   * a numeric suffix to ensure uniqueness of the name.
   * @param {string} characterName  Unique name of the character.
   * @return {boolean} True if successful.
   */
  selectCharacterByName: function(characterName) {
    var index = characterName ?
        this.getCharacterIndex(characterName) : undefined;
    var success = index != undefined;
    if (index != this.ui.selected) {
      this.ui.selected = index;
      this.update();
      if (success) {
        this.dispatchEvent('character-selected', success ? 
            this.characterPlacement[index] : null);
      }
    }
    return success;
  },

  /**
   * Updates target selection.  For generic powers, each target needs to be
   * selected separately, and there is constraints on range or allegience.
   * Multiple selection of the same target is also possible. Well defined,
   * powers, indicate if the selection is cummulative, and may impose any
   * constriants.
   * param{{x: integer, y:integer}} position Map coordinates to use as a
   *    reference for selection.  The position may mark the target critter,
   *    burst center, or blast direction.
   */
  selectTargets: function(position) {
    if (this.ui.selected != undefined && this.ui.activePower) {
      var power = this.ui.activePower;
      // Burst, blast, and single target powers are reset so that the new
      // selection replaces the former.  Generic and mutli-target powers
      // are cummulative.
      if (power.resetSelectionOnUpdate())
        this.ui.targets = [];
      for (var i = 0; i < this.characterPlacement.length; i++) {
        if (power.selectionMatch(position, this.characterPlacement[i])) {
          this.ui.targets.push(i);
        }
      }
    }
    this.update();
  },

  reset: function() {
    dungeon.Game.prototype.reset.call(this);

    this.ui = {
      selected: undefined,
      mapImages: [],
      stale: false,
    };

    this.characterList = {};
    var characters = $('sidebar-character-list').getElementsByClassName('character-button');
    for (var i = characters.length - 1; i >= 0; i--) {
      if (characters[i].getAttribute('id') != 'character-template')
        characters[i].parentNode.removeChild(characters[i]);
    }
    var messageArea = document.getElementById('combat-message-area');
    if (messageArea)
      messageArea.textContent = '';
    this.dispatchEvent('log', 'Welcome to dungeon.');

    // Map related.
    this.rebuildTiles();
  },

  resize: function() {
    var element = this.canvas.parentNode;
    this.canvas.setAttribute('width', element.clientWidth);
    this.canvas.setAttribute('height', element.clientHeight);
    this.update();
  },

  /**
   * Broadcasts an event, which will be processed by all clients.
   * @param {json} eventData Raw data in JSON format describing the event.
   * @param {boolean=} opt_force Set to true to mark an important event which
   *     should be requeued if a previous event is still being processed.
   */
  sendEvent: function(eventData, opt_force) {
    this.socket.emit('e', this.events.length, eventData);
  },

  receiveEvent: function(eventData) {
    // TODO(flackr): processEvent can return false if the event description is
    // not possible to execute given the current game state. If this happens it
    // is likely that the game state is incorrect.
    if (this.processEvent(eventData))
      this.update();
  },

  logMessage: function(text) {
    load($('combat-tracker-page'), function() {
      var messageArea = $('combat-message-area');
      var clientHeight = messageArea.clientHeight;
      var scrollHeight = messageArea.scrollHeight;
      var scrollTop = messageArea.scrollTop;
      var div = document.createElement('div');
      div.className = 'combat-message';
      div.textContent = text;
      messageArea.appendChild(div);
      // Auto-scroll if at the bottom of the message area.
      var top = div.offsetTop;
      var height = div.clientHeight;
      if (top <= scrollTop + clientHeight && top + height > scrollTop + clientHeight)
        messageArea.scrollTop = scrollHeight + height - clientHeight;
    });
  },

  displayBannerMessage: function(text) {
    var banner = $('map-banner-message');
    banner.textContent = text;
    // Animate fade.
    banner.classList.remove('fade-out');
    setTimeout(function() {
      banner.classList.add('fade-out');
    }, 0);
  },

  onUsePower: function(powerName, data) {
    if (this.ui.selected !== undefined) {
      var evt = {
        type: 'use-power',
        character: this.ui.selected,
        power: powerName
      };
      evt.data = data;
      this.sendEvent(evt);
    }
  },

  setCombatState: function(state) {
    if (state == 'start' && this.combatState != 'stopped')
      state = 'resume';
    this.sendEvent({type: 'combat-state-change', state: state});
    if (state == 'start') {
      // TODO(kellis): Reset message log.

      // Set initiative.
      var msgLog = [];
      var characterTypeMap = {};
      var initiativeMap = {};
      for (var i = 0; i < this.characterPlacement.length; i++) {
        var character = this.characterPlacement[i];
        var type = character.source.name;
        var entry = characterTypeMap[type];
        if (!entry) {
          var score = this.rollInitiative(character, msgLog);
          entry = characterTypeMap[type] = {initiative: score, list: []};
          if (!initiativeMap[score])
            initiativeMap[score] = [];
          initiativeMap[score].push(character.source);
        }
        entry.list.push(character);
      }
      // Tie breaks.
      while (true) {
        foundCollision = false;
        for (var entry in initiativeMap) {
          var list = initiativeMap[entry];
          if (list.length > 1) {
            msgLog.push('Initiative tiebreak!');
            foundCollision = true;
            for (var i = 0; i < list.length; i++) {
              var score = this.rollInitiative(list[i], msgLog);
              var revisedScore = String(entry) + '.' + score;
              msgLog.push('Revised initiative = ' + revisedScore);
              if (!initiativeMap[revisedScore])
                initiativeMap[revisedScore] = [];
              initiativeMap[revisedScore].push(character.source);
              characterTypeMap[list[i].name].initiative = revisedScore;
            }
            initiativeMap[entry] = [];
          }
        }
        if (!foundCollision)
          break;
      }
      // Synchronize initiative order across clients.
      var evt = {
        type: 'set-initiative-order',
        order: [],
        log: msgLog
      }
      for (var i = 0; i < this.characterPlacement.length; i++) {
         var character = this.characterPlacement[i];
         var entry = characterTypeMap[character.source.name];
         evt.order.push({name: character.name, initiative: entry.initiative});
      }
      this.sendEvent(evt);

    } else if (state == 'stop') {
      // Restore encounter powers for players.
    }
  },

  rollInitiative: function(characterData, msgLog) {
    if (characterData.source)
      characterData = characterData.source;
    var name = name;
    var initiative = parseInt(characterData.stats['Initiative']);
    var score = Math.floor(Math.random() * 20 + 1);
    var msg = characterData.name + ' rolls initiative.\n' +
        'd20 + ' + initiative + ' = (' + score + ') ' + ' + ' + initiative +
        ' = ' + (score += initiative) + '\n';
    msgLog.push(msg);
    score = String(score);
    if (score.length == 1)
      score = '0' + score;
    return score;
  },

  onCombatStateChanged: function(state) {
    switch(state) {
    case 'start':
      this.combatState = 'started';
      break;
    case 'resume':
      this.combatState = 'resumed';
      break;
    case 'pause':
      this.combatState = 'paused';
      break;
    case 'stop':
      this.combatState = 'stopped';
      break;
    default:
      console.log('Unknown combat state: ' + state);
    }
    // update disabled state of combat controls
    $('combat-start-button').setAttribute('disabled', 
        this.combatState == 'started' || this.combatState == 'resumed');
    $('combat-pause-button').setAttribute('disabled', 
        this.combatState  == 'paused' || this.combatState == 'stopped');
    $('combat-stop-button').setAttribute('disabled', 
        this.combatState  == 'stopped');
    var msg = 'Combat ' + this.combatState + '.';
    this.dispatchEvent('log',  msg); 
    this.dispatchEvent('banner-message', msg);
  },

  onInitiativeOrderChanged: function(list, log) {
    for (var i = 0; i < log.length; i++)
      this.dispatchEvent('log', log[i]);
    for (var i = 0; i < list.length; i++) {
      var entry = list[i];
      var index = this.getCharacterIndex(entry.name);
      if (index != undefined) {
        this.characterPlacement[index].initiative = entry.initiative;
        this.dispatchEvent('character-updated', index);
      }
    }
    // Update ordering in combat overview.
    this.combatTracker.sortIntoInitiativeOrder();
    this.combatOverviewPage.sortIntoInitiativeOrder();
  },

  /**
   * Deselect character if removed from game.
   */
  onRemoveCharacter: function(characterName) {
    var index = this.getCharacterIndex(characterName);
    if (index == this.ui.selected) {
      this.ui.selected = undefined;
      this.update();
    } 
  },

  onSelectView: function(category, view) {
    // Check if page is already active
    var isActive = !!$(view + '-selector').getAttribute('active');
    var isVisible = !$(view + '-page').hidden;
    if (isActive == isVisible)
      return;

    var selectors = document.getElementsByClassName(category + '-selector');
    for (var i = 0; i < selectors.length; i++)
      selectors[i].setAttribute('active', false);
    var pages = document.getElementsByClassName(category);
    for (var i = 0; i < pages.length; i++) {
      pages[i].hidden = true;
    }
    $(view + '-selector').setAttribute('active', true);
    $(view + '-page').hidden = false;

    if (view == 'combat-tracker')
      this.onSelectView('page', 'map');
  },

  onTouchStart: function(e) {
    e.preventDefault();
    function convertSingleTouchEvent(e) {
      if (e.changedTouches.length > 0) {
        e.clientX = e.changedTouches[0].clientX;
        e.clientY = e.changedTouches[0].clientY;
      }
      return e;
    }
    function convertSingleTouchHandler(fn, e) {
      fn(convertSingleTouchEvent(e));
    }
    e = convertSingleTouchEvent(e);
    if (e.changedTouches.length == 1) {
      this.pointer = {
        listeners: {
          touchend: convertSingleTouchHandler.bind(null, this.onPointerUp.bind(this)),
          touchmove: convertSingleTouchHandler.bind(null, this.onPointerMove.bind(this)),
          touchcancel: convertSingleTouchHandler.bind(null, this.onPointerOut.bind(this))}};
      this.onPointerDown(e);
    } else {
      // More than 1 touch cancels.
      this.onPointerOut(e);
    }
  },

  onMouseMove: function(e) {
    if (!this.pointer)
      this.onPointerHover(e);
  },

  onMouseDown: function(e) {
    e.preventDefault();
    this.pointer = {
      listeners: {
        mouseup: this.onPointerUp.bind(this),
        mouseout: this.onPointerOut.bind(this),
        mousemove: this.onPointerMove.bind(this)}
    };
    var selectedTile = dungeon.MapEditor.selectedTile();
    var selectedSize = dungeon.MapEditor.selectedSize();
    if (selectedTile == -1) {
      this.onPointerDown(e);
    } else {
      var lastpos = this.computeMapCoordinates(e);

      var self = this;
      var paint = function(pos) {
        if (self.map.length > pos.y && self.map[pos.y].length > pos.x) {
          if (selectedSize == 0) {
            var obj = {x: pos.x, y: pos.y, tile: selectedTile, w: 2, h: 2};
            self.sendEvent({type: 'add-object', details: obj});
          } else {
            pos.type = 'change';
            pos.value = selectedTile;
            pos.size = selectedSize;
            self.sendEvent(pos);
          }
        }
      };

      paint(lastpos);
      var move = function move(e) {
        var pos = self.computeMapCoordinates(e);
        if (pos.y == lastpos.y && pos.x == lastpos.x)
          return;
        lastpos = pos;
        paint(pos);
      };

      var cancel = function() {
        self.canvas.removeEventListener('mousemove', move);
        self.canvas.removeEventListener('mouseup', cancel);
        self.canvas.removeEventListener('mouseout', cancel);
      };
      this.canvas.addEventListener('mousemove', move);
      this.canvas.addEventListener('mouseup', cancel);
      this.canvas.addEventListener('mouseout', cancel);
    }
  },

  onPointerDown: function(e) {
    if (dungeon.MapEditor.selectedSize() == 0 &&
        this.ui.selectedObject !== undefined) {
      var objIndex = this.ui.selectedObject;
      var evt = this.computeMapCoordinates(e);
      var posx = evt.x - this.objects[objIndex].x;
      var posy = evt.y - this.objects[objIndex].y;
      if (posx < 0 || posy < 0 || posx >= this.objects[objIndex].w || posy >= this.objects[objIndex].h) {
        this.pointer.mode == 'select';
      } else {
        this.pointer.startx = evt.x;
        this.pointer.starty = evt.y;
        this.pointer.offx = posx;
        this.pointer.offy = posy;
        if (posx == this.objects[objIndex].w - 1 &&
            posy == this.objects[objIndex].h - 1)
          this.pointer.mode = 'resize';
        else
          this.pointer.mode = 'move';
      }
    } else {
      this.pointer.mode = 'select';
    }
    this.pointer.x1 = e.clientX;
    this.pointer.y1 = e.clientY;
    this.pointer.mapX = this.viewport.x;
    this.pointer.mapY = this.viewport.y;
    for (var i in this.pointer.listeners)
      this.canvas.addEventListener(i, this.pointer.listeners[i]);
  },

  onPointerMove: function(e) {
    var deltaX = e.clientX - this.pointer.x1;
    var deltaY = e.clientY - this.pointer.y1;
    var dragThreshold = 10;
    if (this.pointer.mode == 'resize') {
      var evt = this.computeMapCoordinates(e);
      var object = this.objects[this.ui.selectedObject];
      if (object.w == evt.x - object.x + 1 &&
          object.h == evt.y - object.y + 1)
        return;
      this.sendEvent({type: 'update-object',
                      index: this.ui.selectedObject,
                      details: {w: evt.x - object.x + 1,
                                h: evt.y - object.y + 1}});
    } else if (this.pointer.mode == 'move') {
      var evt = this.computeMapCoordinates(e);
      var newx = evt.x - this.pointer.offx;
      var newy = evt.y - this.pointer.offy;
      var object = this.objects[this.ui.selectedObject];
      if (object.x == newx && object.y == newy)
        return;
      this.sendEvent({type: 'update-object',
                      index: this.ui.selectedObject,
                      details: {x: newx, y: newy}});
    } else if (this.pointer.dragStarted || Math.abs(deltaX) + Math.abs(deltaY) > dragThreshold) {
      this.pointer.dragStarted = true;
      this.viewport.x = (this.pointer.mapX - deltaX / this.viewport.tileSize);
      this.viewport.y = (this.pointer.mapY - deltaY / this.viewport.tileSize);
      this.update();
    }
  },

  onPointerHover: function(e) {
    if (this.ui.selected !== undefined) {
      var evt = this.computeMapCoordinates(e);
      if (this.ui.activePower) {
        // Conditional update of selection on hover.
        var power = this.ui.activePower;
        if (power.selectOnMove() &&
            power.getPhase() == dungeon.Power.Phase.TARGET_SELECTION)
          this.selectTargets(evt);
      } else {
        // TODO: Should moves be treated as a special category of powers?
        if (!this.ui.path || this.ui.path.dx != evt.x || this.ui.path.dy != evt.y) {

          this.ui.path = {dx: evt.x, dy: evt.y,
                          path: this.computePath(this.characterPlacement[this.ui.selected],
                                                 evt.x, evt.y)};
          this.update();
        }
      }
    }
  },

  onPointerOut: function(e) {
    for (var i in this.pointer.listeners)
      this.canvas.removeEventListener(i, this.pointer.listeners[i]);
    this.pointer = null;
  },

  onPointerUp: function(e) {
    for (var i in this.pointer.listeners)
      this.canvas.removeEventListener(i, this.pointer.listeners[i]);
    if (this.pointer.dragStarted) {
      this.pointer = null;
      return;
    }
    this.pointer = null;
    var evt = this.computeMapCoordinates(e);
    if (evt.x < 0 || evt.y < 0 || evt.x >= this.map[0].length || evt.y >= this.map.length)
      return;

    if (dungeon.MapEditor.selectedSize() == 0) {
      // Object selection mode.
      for (var i = this.objects.length - 1; i >= 0; i--) {
        if (this.objects[i].x <= evt.x && evt.x <= this.objects[i].x + this.objects[i].w &&
            this.objects[i].y <= evt.y && evt.y <= this.objects[i].y + this.objects[i].h) {
          this.ui.selectedObject = i;
          return;
        }
      }
      delete this.ui.selectedObject;
      return;
    }

    if (this.ui.activePower) {
      // Update target selection if power is selected.
      var power = this.ui.activePower;
      if(power.getPhase() == dungeon.Power.Phase.TARGET_SELECTION) {
        this.selectTargets(evt);
      }
      return;
    } else {
      // If target square is occupied, select the character.
      // For creature size large and up, the placement index marks the top left corner.
      for (var i in this.characterPlacement) {
        var width = this.getCharacterWidthInTiles(i);
        var char = this.characterPlacement[i];        
        if (evt.x >= char.x && evt.x < char.x + width &&
            evt.y >= char.y && evt.y < char.y + width) {
          if (this.ui.selected == i && width > 1) {
            // Hack to allow large creatures to shift 1 square to the right or
            // down. Should really keep track of where on the critter we
            // initiated the selection so that we can track the delta.
            break;
          }
          this.ui.selected = i;
          this.ui.path = null;
          this.dispatchEvent('character-selected', this.characterPlacement[i]);
          this.update();
          return;
        }
      }
    }
    // If no power is active and target square is empty, then move the selected character.
    if (this.ui.selected !== undefined) {
      evt.type = 'move';
      evt.index = this.ui.selected;
      this.ui.selected = undefined;
      this.update();
      this.sendEvent(evt);
      return;
    }
  },
  
  onMouseWheel: function(e) {
    var delta = e.wheelDelta/120;
    var mouse = this.computeMapCoordinatesDouble(e);
    this.zoom(delta, mouse);
  },
  
  onKeyUp: function(e) {
    var key = e.keyCode;
    if (key == 187 || key == 107) // = or numpad +
      this.zoom(1);
    else if (key == 189 || key == 109) // - or numpad -
      this.zoom(-1);
    else if (key == 32 || key == 13) {
      this.attackSelectedTargets();
    } else if (key == 27) {
      this.cancelSelectedTarget();
    }
  },

  attackSelectedTargets: function() {
    if (this.ui.targets) {
      this.attackTargets();
    }
  },

  cancelSelectedTarget: function() {
      if (this.ui.targets) {
        this.ui.targets.pop();
        this.update();
      }
  },
  
  /*
  @param {number} delta Number of zoom steps.  Negative for zooming out and positive for zooming in.
  @param {{x:number, y:number}} mouse Float tile x and y on the map.
  */
  zoom: function(delta, mouse) {
    var oldTileSize = this.viewport.tileSizeFloat;
    var newTileSize = Math.max(1, oldTileSize * Math.pow(1.1, Math.floor(delta)));
    this.viewport.tileSizeFloat = newTileSize;
    newTileSize = Math.round(newTileSize);
    var zoomRatio = (newTileSize - Math.round(oldTileSize)) / newTileSize;
    if (zoomRatio != 1) {
      if (mouse) {
        this.viewport.x += ((mouse.x - this.viewport.x) * zoomRatio);
        this.viewport.y += ((mouse.y - this.viewport.y) * zoomRatio);
      }
      this.viewport.tileSize = newTileSize;
      this.update();
    }
    
  },

  attackResult: function(attacker, attackees, power, tohits, dmg) {
    var attackedStat = power.defense;
    var result = {
      type: 'attack-result',
      characters: [],
      log: '',
    }
    for (var i = 0; i < attackees.length; i++) {
      var defStat = parseInt(this.getCharacterAttribute(
          this.characterPlacement[attackees[i]],
          attackedStat));
      if (defStat <= tohits[i]) {
        //TODO: Flag critical hit, or miss.
        result.log += this.characterPlacement[attacker].name + ' hits ' +
          this.characterPlacement[attackees[i]].name + ' for ' + dmg[i] + ' damage.\n';
        var temps = 0;
        if (this.characterPlacement[attackees[i]].condition.stats['Temps'])
          temps = parseInt(this.characterPlacement[attackees[i]].condition.stats['Temps']);
        var newhp = parseInt(this.characterPlacement[attackees[i]].condition.stats['Hit Points']);
        temps = temps - dmg[i];
        if (temps < 0) {
          newhp += temps;
          temps = 0;
        }
        result.characters.push(
            [attackees[i],
             {'Hit Points': newhp,
              'Temps': temps}]);
      } else {
        result.log += this.characterPlacement[attacker].name + ' misses ' +
          this.characterPlacement[attackees[i]].name + '.\n';
      }
    }
    this.sendEvent(result);
  },

  /**
   * Show attack results to DM for final blessing.
   * @param {Object} message Message containing the attack details.
   *    See dmAttackResult for a full description of the message.
   */
  onDmAttackResultMsg: function(message) {
    var role = document.body.parentNode.getAttribute('role');
    if (role == 'dm') {
      this.dmAttackResult(message.result);
    }
  },

  /**
   * 
   */
  dmAttackResult: function(result) {
    var role = document.body.parentNode.getAttribute('role');
    if (role == 'dm') {
      var dialog = dungeon.Dialog.getInstance('use-power');
      dialog.update(result);
      dialog.show();
    } else {
      var message = {
        type: 'dm-attack-result',
        result: result
      }
      this.sendEvent(message);
    }
  },

  computeMapCoordinatesDouble: function(e) {
    var x = e.clientX;
    var y = e.clientY;
    var element = this.canvas;
    while (element != document.body.parentNode) {
      x -= element.offsetLeft - element.scrollLeft;
      y -= element.offsetTop - element.scrollTop;
      element = element.parentNode;
    }
    var w = parseInt(this.canvas.getAttribute('width'));
    var h = parseInt(this.canvas.getAttribute('height'));
    var coords = {
      x: (x - w/2)/this.viewport.tileSize + this.viewport.x,
      y: (y - h/2)/this.viewport.tileSize + this.viewport.y
    };
    return coords;
  },

  computeMapCoordinates: function(e) {
    var coords = this.computeMapCoordinatesDouble(e);
    coords.x = Math.floor(coords.x);
    coords.y = Math.floor(coords.y);
    return coords;
  },

  onCharacterDragOver: function(e) {
    e.stopPropagation();
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';
  },

  onCharacterDrop: function(e) {
    var coords = this.computeMapCoordinates(e);
    //TODO(kevers): Ability to remove characters from sidebar and map.
    var xml = e.dataTransfer.getData('text/xml');
    var parser=new DOMParser();
    var xmlDoc = parser.parseFromString(xml, "text/xml");
    var node = xmlDoc.getElementsByTagName('character')[0];
    if (!node)
      return;
    var name = node.getAttribute('name');
    if (name) {
      var found = false;
      for (var i = 0; i < this.characterRegistry.length; i++) {
        if (this.characterRegistry[i].name == name) {
          found = true;
          break;
        }
      }
      if (!found)
        return;
      var characterData = {
        name: name,
        x: coords.x,
        y: coords.y
      }
      var evt = {
        type: 'add-character-instance',
        character: characterData
      }
      this.sendEvent(evt);
    }
  },

  onFileDragOver: function(e) {
    e.stopPropagation();
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';
  },

  loadMapTile: function(file) {
    var reader = new FileReader();
    var filename = file.name;
    var self = this;

    reader.onload = function(evt) {
      // Assuming image content, encoding as base64 uri.
      var evt = {
        type: 'add-tile',
        image: evt.target.result,
      };
      self.sendEvent(evt);
    }
    reader.readAsDataURL(file);
  },

  saveMap: function() {
    var mapData = JSON.stringify({
      type: 'map',
      map: this.map,
      mapTiles: this.mapTiles,
    });
    window.open('data:text;charset=utf-8,' + encodeURI(mapData));
  },

  onFileDrop: function(e) {
    var files = e.dataTransfer.files;
    this.loadFiles(files, this.loadFile.bind(this));
  },

  onFileSelect: function(e) {
    var files = e.target.files;
    this.loadFiles(files, this.loadFile.bind(this));
  },

  loadFile: function(file) {
    var filename = file.name;
    var extension = filename.substr(filename.lastIndexOf('.') + 1);
    if (extension == 'png' ||
        extension == 'jpg' ||
        extension == 'jpeg' ||
        extension == 'svg' ||
        extension == 'gif' ||
        extension == 'bmp') {
      this.loadMapTile(file);
    } else if (extension == 'dnd4e' || extension == 'monster') {
      // character or monster.
      dungeon.ParseFile(this, file);
    } else {
      // map.
      dungeon.ParseFile(this, file);
    }
  },

  /**
   * Loads one or more files.  This is the entry point for all file types.
   * Currently only D&D player files (dnd4e extension) are handled.  More to
   * follow.
   * @param {File|FileList} file File or list of files to load.
   * @param {function(file, DungeonClient)} handler Function to call per file.
   */
  loadFiles: function(file, handler) {
    if (file) {
      if (file instanceof FileList) {
        for (var i = 0; i < file.length; i++)
          this.loadFiles(file[i], handler);
      } else {
        handler(file);
      }
    }
  },

  rebuildTiles: function() {
    for (var i = 0; i < this.mapTiles.length; i++) {
      if (!this.ui.mapImages[i])
        this.ui.mapImages[i] = new Image();

      // TODO: Only reset images when necessary.
      this.ui.mapImages[i].src = this.mapTiles[i].src;
      this.ui.mapImages[i].onload = this.update.bind(this);
    }
    this.ui.mapImages.splice(this.mapTiles.length, this.ui.mapImages.length);
    dungeon.MapEditor.loadTiles(this.mapTiles);
  },

  updateCharacterRegistry: function(character) {
    var name = character.name;
    // Update in character list.
    if (name in this.characterList)
       this.updateCharacter(character);
    else
       this.addCharacter(character);
  },

  addCharacter: function(characterData) {
    var element = new dungeon.CharacterButton(this, characterData); 
    this.characterList[characterData.name] = element;
    var list = $('sidebar-character-list');
    var nodes = list.getElementsByClassName('character-button');
    var insertIndex = -1;
    for (var i = 0; i < nodes.length; i++) {
      var name = nodes[i].getElementsByClassName('character-button-title')[0].textContent.trim();
      if (name > characterData.name) {
        insertIndex = i;
        break;
      }
    }
    if (insertIndex >= 0)
      list.insertBefore(element, nodes[insertIndex]);
    else
      list.appendChild(element);
  },

  updateCharacter: function(characterData) {
     //TODO(kellis): Implement me.
  },

  update: function() {
    // If the UI is marked stale already then a redraw should have already
    // been queued.
    if (!this.ui.stale) {
      this.ui.stale = true;
      requestAnimFrame(this.redraw.bind(this));
    }
  },

  computePath: function(character, dest_x, dest_y) {
    var self = this;
    // Computes a best case movement for a character.
    var h = function(dx, dy) {
      var d = Math.max(dx, dy);
      d += Math.max(0, Math.min(dx, dy) - Math.floor(d / 2));
      return d;
    }
    var compute_score = function(info) {
      // TODO: Allow shifting by more than 1 for certain characters.
      return (info.d > 1 ? (info.oa * 100) : 0) + info.d + (info.diag ? 0.5 : 0);
    }
    var in_bounds = function(x, y) {
      return x >= 0 && y >= 0 && y < self.map.length && x < self.map[0].length;
    }
    var char_team = function(character) {
      return character.source.charClass == 'Monster' ? 2 : 1;
    }
    var enemies_adjacent = function(x, y, radius, team) {
      var enemies = 0;
      for (var i = 0; i < self.characterPlacement.length; i++) {
        if ((!team || char_team(self.characterPlacement[i]) != team) &&
            Math.abs(self.characterPlacement[i].x - x) <= radius &&
            Math.abs(self.characterPlacement[i].y - y) <= radius)
        enemies++;
      }
      return enemies;
    }
    var direction = [[-1, 0], [0, -1], [1, 0], [0, 1],
                     [-1, -1], [1, -1], [1, 1], [-1, 1]];
    var pq = new PriorityQueue();
    pq.enqueue(0, {x: character.x, y: character.y, oa: 0, d: 0, diag: false, score: 0});
    var path = [];
    var queue = [];
    var pos;
    var move_team = char_team(character);
    // TODO: Stop searching when the heuristic distance calculation is further
    // than our range instead of searching up to our range.
    while (pos = pq.dequeue()) {
      if (pos.d > parseInt(character.condition.stats.Speed) + 2)
        continue;
      if (!path[pos.y]) path[pos.y] = [];
      if (path[pos.y][pos.x] && path[pos.y][pos.x].score <= pos.score)
        continue;
      path[pos.y][pos.x] = pos;
      if (pos.y == dest_y && pos.x == dest_x)
        break;
      for (var i = 0; i < direction.length; i++) {
        var next = {x: pos.x + direction[i][0],
                    y: pos.y + direction[i][1]};
        if (!in_bounds(next.x, next.y) ||
            enemies_adjacent(next.x, next.y, 0))
          continue
        // TODO: Only allow each enemy to opportunity attack once.
        next.oa = pos.oa + enemies_adjacent(pos.x, pos.y, 1, move_team);
        next.d = pos.d + 1;
        next.diag = false;
        if (i >= 4) {
          if (pos.diag)
            next.d++;
          else
            next.diag = true;
        }
        next.dir = i;
        next.score = compute_score(next);
        pq.enqueue(next.score + h(Math.abs(dest_x - next.x), Math.abs(dest_y - next.y)), next);
      }
    }
    if (path && path[dest_y] && path[dest_y][dest_x]) {
      var dir;
      var spath = [];
      while(dest_y != character.y || dest_x != character.x) {
        spath.push(pos = path[dest_y][dest_x]);
        dest_x -= direction[pos.dir][0];
        dest_y -= direction[pos.dir][1];
      }
      spath.push(path[dest_y][dest_x]);
      spath.reverse();
      for (var i = 0; i < spath.length - 1; i++)
        spath[i].dir = spath[i + 1].dir;
      return spath;
    }
    return null;
  },

  drawHealthBar: function(ctx, hx, hy, hw, hh, character, isMonster, role) {
    // Health bars
    // Black border
    ctx.fillStyle = '#000';
    ctx.fillRect(hx - 1, hy - 1, hw + 2, hh + 2);
    // Interior
    var curHp = Number(character.condition.stats['Hit Points']);
    var maxHp = Number(character.source.stats['Hit Points']);
    var hpFraction = curHp / maxHp;
    var bloodyHp = Number(character.source.stats['Bloodied']);
    var isBloodied = (curHp <= bloodyHp);
    var isDying = (curHp <= 0);
    var temps = parseInt(character.condition.stats['Temps'] || 0);
    if (isMonster) {
      ctx.fillStyle = isBloodied ? '#f80' : '#0f0';
      if (role == 'dm') {
        if (hpFraction > 0)
          ctx.fillRect(hx, hy, Math.min(1, hpFraction) * hw, hh);
      } else {
        ctx.fillRect(hx, hy, isBloodied ? hw / 2 : hw, hh);
      }
      ctx.fillStyle = '#000';
      ctx.fillRect(Math.round(hx + hw / 2), hy, 1, hh);
    } else {
      ctx.fillStyle = isDying ? '#f00' : (isBloodied ? '#f80' : '#0f0');
      var total = bloodyHp + maxHp + temps;
      var healthRatio = (bloodyHp + curHp) / total;
      var healthWidth = Math.round(healthRatio * hw);
      ctx.fillRect(hx, hy, healthWidth, hh);
      if (temps > 0) {
        var tempRatio = temps / total;
        var tempWidth = Math.round(tempRatio * hw);
        if (healthWidth + tempWidth > hw)
          tempWidth = hw - healthWidth;
        ctx.fillStyle = '#ff0';
        ctx.fillRect(hx + healthWidth, hy, tempWidth, hh);
      }
      ctx.fillStyle = '#000';
      var bloodyRatio = bloodyHp / total;
      var DyingMarker = Math.round(bloodyRatio * hw);
      ctx.fillRect(hx + DyingMarker, hy, 1, hh);
      var BloodyMarker = Math.round(2 * bloodyRatio * hw);
      ctx.fillRect(hx + BloodyMarker, hy, 1, hh);
    }
  },

  drawTextInBounds: function(ctx, x_center, y, text, x_left, x_right, textColor, textHeight) {
    var maxWidth = Math.round(x_right - x_left);
    var textWidth;
    while ((textWidth = ctx.measureText(text).width) > maxWidth)
      text = text.substring(0, text.length - 1);
    var x = Math.round(Math.min(x_right - textWidth,
                                Math.max(x_left, x_center - textWidth / 2)));
    ctx.fillStyle = 'white';
    ctx.globalAlpha = 0.6;
    ctx.fillRect(x, y - textHeight - 1, textWidth, textHeight + 2);
    ctx.globalAlpha = 1;
    ctx.fillStyle = textColor;
    ctx.fillText(text, x, y);
  },

  redraw: function() {
    this.ui.stale = false;
    var ctx = this.canvas.getContext('2d');
    var w = parseInt(this.canvas.getAttribute('width'));
    var h = parseInt(this.canvas.getAttribute('height'));
    var view = {
      x1: Math.max(0, Math.floor(this.viewport.x - w / this.viewport.tileSize / 2)),
      y1: Math.max(0, Math.floor(this.viewport.y - h / this.viewport.tileSize / 2)),
      x2: Math.min(this.map[0].length, Math.ceil(this.viewport.x + w / this.viewport.tileSize / 2)),
      y2: Math.min(this.map.length, Math.ceil(this.viewport.y + h / this.viewport.tileSize / 2)),
    };
    var baseX = Math.floor(w / 2 - (this.viewport.x - view.x1) * this.viewport.tileSize);
    var baseY = Math.floor(h / 2 - (this.viewport.y - view.y1) * this.viewport.tileSize);
    var tw = this.viewport.tileSize;

    // Draw a black background
    ctx.fillStyle = '#000';
    ctx.fillRect(0, 0, w, h);

    for (var i = view.y1; i < view.y2; i++) {
      for (var j = view.x1; j < view.x2; j++) {
        ctx.drawImage(this.ui.mapImages[this.map[i][j]],
                      baseX + (j - view.x1) * this.viewport.tileSize,
                      baseY + (i - view.y1) * this.viewport.tileSize, 
                      this.viewport.tileSize, this.viewport.tileSize);
      }
    }

    for (var i = 0; i < this.objects.length; i++) {
      var object = this.objects[i];
      if (object.x + object.w <= view.x1 || object.y + object.h <= view.y1 ||
          object.x >= view.x2 || object.y >= view.y2)
        continue;
      ctx.drawImage(this.ui.mapImages[object.tile],
                    baseX + (object.x - view.x1) * this.viewport.tileSize,
                    baseY + (object.y - view.y1) * this.viewport.tileSize,
                    this.viewport.tileSize * object.w,
                    this.viewport.tileSize * object.h);
    }
    
    // Draw grid.
    ctx.beginPath();
    ctx.lineWidth = 1;
    ctx.strokeStyle = 'rgba(0, 0, 0, 0.5)';
    for (var i = view.y1; i < view.y2; i++) {
    	var y = baseY + (i - view.y1) * this.viewport.tileSize;
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
    }
    
    for (var i = view.x1; i < view.x2; i++) {
      var x = baseX + (i - view.x1) * this.viewport.tileSize;
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
    }
    ctx.stroke();

    // Mark selected character and indicate movement range.
    if (this.ui.selected != undefined) {
      this.drawCharacter(this.ui.selected, 'selection', view, baseX, baseY);
        
      // Movement overlay
      ctx.fillStyle = "rgba(255, 255, 255, 0.3)";
      var character = this.characterPlacement[this.ui.selected];
      var speed = parseInt(character.condition.stats['Speed'] || 0);
      // Check if creature is prone, immobalized, or slowed.
      var effects = character.condition.effects;
      if (effects) {
        for (var j = 0; j < effects.length; j++) {
          var effect = effects[j];
          if (effect == 'prone' || effect == 'immobalized' || effect == 'grabbed') {
            speed = 0;
            break;
          }
          if (effect == 'slowed')
            speed = 2;
        }
      }
      var width = this.getCharacterWidthInTiles(this.ui.selected);
      for (var j = -speed; j < speed + width; j++) {
        for (var k = -speed; k < speed + width; k++) {
          var dx = j < 0 ? j : j >= width ? j - width + 1 : 0;
          var dy = k < 0 ? k : k >= width ? k - width + 1 : 0;
          if (Math.sqrt(dx * dx + dy * dy) <= (speed + 0.8))
            ctx.fillRect(baseX + (character.x + j - view.x1) * tw,
                         baseY + (character.y + k - view.y1) * tw,
                         tw,
                         tw);
        }
      }
    }

    // Draw target indicators.  Critters may be targetted multiple times.
    if (this.ui.targets) {
      var targetFreq = {};
      for (var j = 0; j < this.ui.targets.length; j++) {
        var index = this.ui.targets[j];
        if (index in targetFreq)
          targetFreq[index]++;
        else
          targetFreq[index] = 1;
      }
      ctx.strokeStyle = '#f00';
      for (var index in targetFreq) {
        var character = this.characterPlacement[index];
        var tw = this.viewport.tileSize;
        var width = tw * this.getCharacterWidthInTiles(index);
        var baseRadius = width / 2 - tw / 4 + 3;
        var x = baseX + (character.x - view.x1) * tw + width / 2;
        var y = baseY + (character.y - view.y1) * tw + width / 2;
        for (var j = 0; j < targetFreq[index]; j++) {
          ctx.beginPath();
          ctx.lineWidth = 2;
          ctx.arc(x, y, baseRadius + j * 3, 0, 2*Math.PI, true);
          ctx.stroke();
        }
      }
    }

    // TODO: Fix path for critters with size >= Large.  Index of critter is in
    // the top left corner.  Path should trace from center or from edge closest
    // to move direction.
    if (this.ui.path && this.ui.path.path && this.ui.path.path.length) {
      ctx.strokeStyle = '#f00';
      ctx.beginPath();
      ctx.lineWidth = 2;
      for (var j = 0; j < this.ui.path.path.length; j++) {
        var x = baseX + (this.ui.path.path[j].x - view.x1) * tw + tw / 2;
        var y = baseY + (this.ui.path.path[j].y - view.y1) * tw + tw / 2;
        if (j == 0)
          ctx.moveTo(x, y);
        else
          ctx.lineTo(x, y);
      }
      ctx.stroke();
    }

    var self = this;
    var mapX = function(x) {
      return baseX + (x - view.x1) * self.viewport.tileSize;
    };
    var mapY = function(y) {
      return baseY + (y - view.y1) * self.viewport.tileSize;
    };

    // Draw critter indicators including names and health bars.
    var role = document.body.parentNode.getAttribute('role');
    for (var i = 0; i < this.characterPlacement.length; i++) {
      var character = this.characterPlacement[i];
      if (character.x < view.x1 || character.x >= view.x2 ||
          character.y < view.y1 || character.y >= view.y2)
        continue;

      var name = character.name;
      var isMonster = character.source.charClass == 'Monster';
      if (i != this.ui.selected)
        this.drawCharacter(i, 'type', view, baseX, baseY);
      this.drawCharacter(i, 'effects', view, baseX, baseY);

      var width = this.getCharacterWidthInTiles(i);
      var x = baseX + (character.x - view.x1) * tw + tw * width / 2;
      var y = baseY + (character.y - view.y1) * tw + tw / 2; 
      this.drawHealthBar(ctx,
                         Math.round(x - tw / 2 + 1 + 1 / 32 * tw),
                         Math.round(y - tw / 2 + 1 + 1 / 32 * tw),
                         Math.max(10, Math.round(tw - 2 - 2 / 32 * 2)),
                         Math.max(1, Math.round(2 / 32 * tw)),
                         character,
                         isMonster,
                         role);

      // Name
      var textHeight = Math.max(10, tw/3);
      ctx.font = textHeight + "px Arial";
      var x_bounds = [0, w - 1];
      for (var j = 0; j < this.characterPlacement.length; j++) {
        if (this.characterPlacement[i].x != this.characterPlacement[j].x && this.characterPlacement[j].y == this.characterPlacement[i].y) {
          if (this.characterPlacement[j].x < this.characterPlacement[i].x) {
            x_bounds[0] = Math.max(x_bounds[0], mapX((this.characterPlacement[j].x + character.x) / 2 + 0.5));
          } else {
            x_bounds[1] = Math.min(x_bounds[1], mapX((this.characterPlacement[j].x + character.x) / 2 + 0.5));
          }
        }
      }
      this.drawTextInBounds(ctx, x, Math.round(y - tw / 2 - tw / 32), name, x_bounds[0], x_bounds[1], isMonster ? '#f00' : '#00f', textHeight);
    }
  },

  /**
   * Returns the width of a critter in tiles, which is dependent on its size
   * category and ranges from 1 to 4.  Multiple tiny critters can fit into the
   * same square. Support for tiny fellas is currently not implemented.
   */
  getCharacterWidthInTiles: function(index) {
    var character = this.characterPlacement[index];
    if (!character)
      return 0;
    var size = character.source.stats['Size'];
    switch(size) {
      case 'Tiny': // Actually two critters per square is allowed for tiny.
      case 'Small':
      case 'Medium':
        return 1;
      case 'Large':
        return 2;
      case 'Huge':
        return 3;
      case 'Gargantuan':
        return 4;
      default:
        return 1;
    }
  },

  /**
   * Draws a character on the map.
   * @param {number} index The character placement index.
   * @param {string} state The state for displaying the character, which may be
   *     one of the following: 'selection', 'type', or 'effects'.
   */
  drawCharacter: function(index, state, view, baseX, baseY) {
    var ctx = this.canvas.getContext('2d');
    var character = this.characterPlacement[index];
    var tw = this.viewport.tileSize;
    var tileWidth = this.getCharacterWidthInTiles(index);
    var radius = tw * tileWidth / 2;
    var x = baseX + (character.x - view.x1) * tw + radius;
    var y = baseY + (character.y - view.y1) * tw + radius;

    var drawStroke = false, drawFill = false;
    ctx.lineWidth = 1;
    switch(state) {
      case 'selection':
        drawStroke = true;
        ctx.strokeStyle = '#ff0';
        ctx.lineWidth = tw/32;
        // Deliberate fall-through.
      case 'type':
        var isMonster = character.source.charClass == 'Monster';
        var effects = character.condition.effects;
        if (effects) {
          for (var j = 0; j < effects.length; j++) {
            var effect = effects[j];
            if (effect == 'pet' || effect == 'dominated')
              isMonster = false;
          }
        }
        drawFill = true;
        ctx.fillStyle = isMonster ? '#f00' : '#00f';
        break;
      case 'effects':
        var hasEffects = character.condition.effects &&
            character.condition.effects.length > 0;
        if (hasEffects) {
          drawStroke = drawFill = true;
          ctx.strokeStyle = '#000';
          ctx.fillStyle = '#ff0';
          x += radius / 2;
          y += radius / 2;
          radius = 0.4 * tw;
        }
        break;
    }
    if (drawStroke || drawFill) {
      ctx.beginPath();
      ctx.arc(x, y, radius - tw/4, 0, 2*Math.PI, true);
      if (drawFill)
        ctx.fill();
      if (drawStroke)
        ctx.stroke();
    }
  },


});

document.addEventListener('DOMContentLoaded', function() {
  load(document.body, function() {
    new dungeon.Client();
  });
});
