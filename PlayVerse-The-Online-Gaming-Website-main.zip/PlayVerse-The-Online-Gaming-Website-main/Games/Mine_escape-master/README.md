Mine_escape
===========

A simple multiplayer game built on Pyramid framework and socket.io