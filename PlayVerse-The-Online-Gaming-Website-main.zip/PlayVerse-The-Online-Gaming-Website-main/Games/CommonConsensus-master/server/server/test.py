def find(num):
    return check(num)

def check(num):
    return num*num
