from flexserver.server.models import Relations, Concepts, RelationTypes, Bads
from django.contrib import admin


admin.site.register(Relations)
admin.site.register(Concepts)
