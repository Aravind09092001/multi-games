/**
 * Helper functions
 */
module.exports = {
    dummy: function() {
    }
};