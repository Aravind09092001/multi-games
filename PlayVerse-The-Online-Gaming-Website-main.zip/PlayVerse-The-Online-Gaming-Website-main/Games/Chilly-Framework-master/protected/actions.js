/**
 * Define actions
 *
 * @param Chilly
 * @param models
 * @param config
 * @param helpers
 */
module.exports = function(Chilly, models, config, helpers) {
    'use strict';
};