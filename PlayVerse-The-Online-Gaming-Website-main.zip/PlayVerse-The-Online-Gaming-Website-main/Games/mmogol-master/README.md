mmogol
======

Massively Multiplayer Online Game of Life

Proof of concept using node.js / socket.io

```bash
npm install
supervisor ./server/app.js
```

Then open up your browser and go to http://localhost:8012
