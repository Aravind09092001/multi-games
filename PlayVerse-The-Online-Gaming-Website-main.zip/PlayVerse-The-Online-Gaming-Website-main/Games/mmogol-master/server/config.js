module.exports = {
	port: 8012,
	clientDir: __dirname + '/../client',
	tickLength: 150, 
	width: 50,
	height: 40
};