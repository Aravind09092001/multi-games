# Shooter game

A multiplayer top down shooter

## Example

## Installation

`npm install Shooter game`

## Contributors

 - Raynos

## MIT Licenced