var Widget = require("./widget")

module.exports = Widget