Action = {
    LEFT: 1,
    RIGHT: 2
}
