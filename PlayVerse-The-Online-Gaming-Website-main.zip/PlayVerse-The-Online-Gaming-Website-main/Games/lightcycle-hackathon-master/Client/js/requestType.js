RequestType = {
    JOIN: 'JOIN',
    ACTION: 'ACTION',
    QUIT: 'PART'
}
