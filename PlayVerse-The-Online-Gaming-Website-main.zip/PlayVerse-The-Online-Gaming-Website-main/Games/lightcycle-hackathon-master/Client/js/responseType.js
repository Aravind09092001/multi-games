ResponseType = {
    STATE: 'STATE'
}
