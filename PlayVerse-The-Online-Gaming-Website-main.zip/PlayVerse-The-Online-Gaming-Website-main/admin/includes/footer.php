<div class="copyrights">
    <p>© 2023 Aravind. All Rights Reserved | <a herf="../index.html">PlayVerse</a></p>
</div>